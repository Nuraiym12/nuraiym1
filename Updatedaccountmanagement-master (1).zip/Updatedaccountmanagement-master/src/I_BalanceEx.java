public class I_BalanceEx extends Exception{
    public I_BalanceEx(String message) {
        super(message);
    }
}
